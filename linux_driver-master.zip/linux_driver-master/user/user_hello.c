#include <stdio.h>
int main(void)
{
    printf("Hello, this is a program compiled by ndk-cross-compiler!\n");
}
